<?php
session_start();

$conn = new mysqli("sql312.infinityfree.com", "if0_39051540", "meRTO72fEeGo", "if0_39051540_dbms");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        // Regenerate session ID on login success
        session_regenerate_id(true);

        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['flatno'] = $user['flatno'];
        $_SESSION['mobno'] = $user['mobno'];
        $_SESSION['fammem'] = $user['fammem'];

        // Redirect to profile page
        header("Location: profile.php");
        exit;
    } else {
        // Redirect to login with error query parameter
        header("Location: login.php?error=invalid_credentials");
        exit;
    }

    $stmt->close();
}

$conn->close();
?>                         