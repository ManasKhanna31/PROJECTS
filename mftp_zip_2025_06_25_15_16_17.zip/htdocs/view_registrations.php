<?php
// Always check password on page load
$error = '';
$show_form = true;
$actual_password = "admin123"; // Change to your secure password

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $entered_password = $_POST['admin_password'] ?? '';
    if ($entered_password === $actual_password) {
        $show_form = false; // password correct, show content
    } else {
        $error = "Incorrect admin password.";
    }
}

if ($show_form) {
    // Show password form every time if not correct
    ?>
    <!DOCTYPE html>
    <html>
    <head><title>Admin Verification</title></head>
    <body>
        <h2>Enter Admin Password</h2>
        <?php if ($error) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="POST">
            <input type="password" name="admin_password" required placeholder="Admin Password" />
            <button type="submit">Access</button>
        </form>
        <a href="profile.php">Cancel</a>
    </body>
    </html>
    <?php
    exit;
}

// If password is correct, proceed to connect to DB and show users
$conn = new mysqli("sql312.infinityfree.com", "if0_39051540", "meRTO72fEeGo", "if0_39051540_dbms");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT username, email, flatno, mobno, fammem FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Users</title>
    <style>
        body { font-family: Arial; margin: 40px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #164863; color: white; }
    </style>
</head>
<body>

<h2>Registered Users</h2>
<table>
    <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Flat No</th>
        <th>Mobile No</th>
        <th>Family Members</th>
    </tr>

<?php
if ($result->num_rows > 0):
    while ($row = $result->fetch_assoc()):
?>
    <tr>
        <td><?= htmlspecialchars($row["username"]) ?></td>
        <td><?= htmlspecialchars($row["email"]) ?></td>
        <td><?= htmlspecialchars($row["flatno"]) ?></td>
        <td><?= htmlspecialchars($row["mobno"]) ?></td>
        <td><?= htmlspecialchars($row["fammem"]) ?></td>
    </tr>
<?php
    endwhile;
else:
?>
    <tr><td colspan="5">No users found.</td></tr>
<?php endif; ?>
</table>

</body>
</html>

<?php $conn->close(); ?>
