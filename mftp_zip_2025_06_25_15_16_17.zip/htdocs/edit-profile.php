<?php
session_start();

$conn = new mysqli("sql312.infinityfree.com", "if0_39051540", "meRTO72fEeGo", "if0_39051540_dbms");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['email'])) {
    die("Unauthorized access. Please <a href='index.html'>login</a>.");
}

$email = $_SESSION['email'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $flatno = $_POST['flatno'];
    $mobno = $_POST['mobno'];
    $fammem = $_POST['fammem'];

    $sql = "UPDATE users SET username=?, flatno=?, mobno=?, fammem=? WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssis", $username, $flatno, $mobno, $fammem, $email);

    if ($stmt->execute()) {
        echo "Profile updated successfully!<br><a href='profile.php'>Back to Profile</a>";
    } else {
        echo "Error updating profile.";
    }

    $stmt->close();
} else {
    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
?>

<h2>Edit Profile</h2>
<form method="POST">
    <label>Username:</label><br>
    <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required><br><br>
    
    <label>Flat No:</label><br>
    <input type="text" name="flatno" value="<?php echo htmlspecialchars($user['flatno']); ?>" required><br><br>
    
    <label>Mobile No:</label><br>
    <input type="text" name="mobno" value="<?php echo htmlspecialchars($user['mobno']); ?>" required><br><br>
    
    <label>Family Members:</label><br>
    <input type="text" name="fammem" value="<?php echo htmlspecialchars($user['fammem']); ?>" required><br><br>
    
    <button type="submit">Update</button>
</form>

<?php
    $stmt->close();
}
$conn->close();
?>
