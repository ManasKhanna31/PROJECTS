function showLogin() {
  document.getElementById("loginForm").style.display = "block";
  document.getElementById("registerForm").style.display = "none";
  document.getElementById("indicator").style.transform = "translateX(0)";

  const tabs = document.querySelectorAll('.tabs span');
  tabs[0].classList.add('active');
  tabs[1].classList.remove('active');
}

function showRegister() {
  document.getElementById("loginForm").style.display = "none";
  document.getElementById("registerForm").style.display = "block";
  document.getElementById("indicator").style.transform = "translateX(100%)";

  const tabs = document.querySelectorAll('.tabs span');
  tabs[1].classList.add('active');
  tabs[0].classList.remove('active');
}

// Set default tab on page load
window.onload = () => showLogin();
