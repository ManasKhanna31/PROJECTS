<?php
// Enable error reporting for debugging (remove on production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
$conn = new mysqli("sql312.infinityfree.com", "if0_39051540", "meRTO72fEeGo", "if0_39051540_dbms");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");

// Check if form data is set
if (
    !isset($_POST['username']) || empty(trim($_POST['username'])) ||
    !isset($_POST['email']) || empty(trim($_POST['email'])) ||
    !isset($_POST['flatno']) || empty(trim($_POST['flatno'])) ||
    !isset($_POST['mobno']) || empty(trim($_POST['mobno'])) ||
    !isset($_POST['fammem']) || empty(trim($_POST['fammem'])) ||
    !isset($_POST['password']) || empty($_POST['password'])
) {
    die("Please fill all required fields.");
}

// Sanitize and assign variables
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$flatno = trim($_POST['flatno']);
$mobno = trim($_POST['mobno']);
$fammem = trim($_POST['fammem']);
$password = $_POST['password'];

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format.");
}

// Hash password securely
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO users (username, email, flatno, mobno, fammem, password) VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Prepare failed: " . htmlspecialchars($conn->error));
}

if (!$stmt->bind_param("ssssss", $username, $email, $flatno, $mobno, $fammem, $hashed_password)) {
    die("Bind failed: " . htmlspecialchars($stmt->error));
}

if ($stmt->execute()) {
    echo "Registration successful.";
} else {
    echo "Error: " . htmlspecialchars($stmt->error);
}

$stmt->close();
$conn->close();
?>
