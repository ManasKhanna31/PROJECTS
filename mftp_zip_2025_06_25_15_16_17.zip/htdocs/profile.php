<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Profile - SocietyHub</title>
<style>
  /* Background Gradient */
  body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #164863, #1e90ff);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #164863;
  }

  /* Card container */
  .profile-card {
    background: #ffffffcc; /* White with slight transparency */
    padding: 30px 40px;
    border-radius: 15px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    max-width: 400px;
    width: 90%;
    text-align: center;
  }

  h2 {
    margin-bottom: 20px;
    color: #164863;
  }

  p {
    font-size: 18px;
    margin: 10px 0;
  }

  a {
    display: inline-block;
    margin: 15px 10px 0 10px;
    padding: 10px 20px;
    background-color: #164863;
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    transition: background-color 0.3s ease;
  }

  a:hover {
    background-color: #0f3057;
  }

  /* Responsive for small devices */
  @media (max-width: 480px) {
    .profile-card {
      padding: 20px;
    }
    p {
      font-size: 16px;
    }
    a {
      padding: 8px 16px;
      font-size: 14px;
    }
  }
</style>
</head>
<body>
  <div class="profile-card">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
    <p><strong>Flat No:</strong> <?php echo htmlspecialchars($_SESSION['flatno']); ?></p>
    <p><strong>Mobile No:</strong> <?php echo htmlspecialchars($_SESSION['mobno']); ?></p>
    <p><strong>Family Members:</strong> <?php echo htmlspecialchars($_SESSION['fammem']); ?></p>

    <a href="edit-profile.php">Edit Profile</a>
    <a href="index.html">Go to Home</a>
    <a href="index.html">Logout</a>
  </div>
</body>
</html>
